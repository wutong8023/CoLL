# Firmiana

Firmiana is a playground for research at the intersection of continual learning, active learning, natural language processing.
Firmiana provides the following two main features to natural language processing community:
- The implementation of typical baseline methods and the respective continual learning settings.
- The interface for customized evaluation.


